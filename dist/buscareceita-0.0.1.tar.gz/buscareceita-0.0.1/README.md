# buscareceita

Description.

Busca dados de CNPJ na API Minha Receita e devolve um Array JSON

## Installation

Use o gerenciador de pacotes [pip] para installar 

## Usage

buscareceita(CNPJ)

## Author
Antonio